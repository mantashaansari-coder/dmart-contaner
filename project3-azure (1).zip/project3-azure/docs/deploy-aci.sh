#!/bin/bash
# ============================================================================
# STAGE 1: Deploy to Azure WITHOUT AKS - using Azure Container Instances (ACI)
# ============================================================================
# This script provisions everything with plain `az` CLI commands:
#   - Resource Group
#   - Azure Container Registry (ACR)
#   - Azure Database for PostgreSQL Flexible Server (+ pgvector)
#   - Storage Account + Blob Container
#   - Azure OpenAI + Document Intelligence (Cognitive Services)
#   - Key Vault for secrets
#   - Two Container Instances (backend + frontend) on a shared vnet
#
# Run this top-to-bottom, OR copy/paste section by section to understand
# what each step does. Designed for beginners - every command is commented.
# ============================================================================

set -e  # stop on first error

# ---------------------------------------------------------------------------
# 0. Variables - EDIT THESE before running
# ---------------------------------------------------------------------------
export RESOURCE_GROUP="doc-platform-rg"
export LOCATION="centralindia"                 # pick a region close to you
export ACR_NAME="docplatformacr$RANDOM"         # must be globally unique
export STORAGE_ACCOUNT="docplatformst$RANDOM"   # must be globally unique, lowercase, no dashes
export PG_SERVER_NAME="doc-platform-pg-$RANDOM" # must be globally unique
export PG_ADMIN_USER="docadmin"
export PG_ADMIN_PASSWORD="$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c 20)Aa1!"
export KEYVAULT_NAME="doc-platform-kv-$RANDOM"
export OPENAI_RESOURCE_NAME="doc-platform-openai"
export DOC_INTEL_RESOURCE_NAME="doc-platform-docintel"

echo "================================================================"
echo " Resource Group : $RESOURCE_GROUP"
echo " Location       : $LOCATION"
echo " ACR Name       : $ACR_NAME"
echo " Storage Account: $STORAGE_ACCOUNT"
echo " Postgres Server: $PG_SERVER_NAME"
echo " Key Vault      : $KEYVAULT_NAME"
echo "================================================================"

# ---------------------------------------------------------------------------
# 1. Login + set subscription
# ---------------------------------------------------------------------------
az login
# az account set --subscription "<your-subscription-id>"   # uncomment if you have multiple subscriptions

# ---------------------------------------------------------------------------
# 2. Resource Group
# ---------------------------------------------------------------------------
az group create --name $RESOURCE_GROUP --location $LOCATION

# ---------------------------------------------------------------------------
# 3. Azure Container Registry (ACR) - stores our Docker images
# ---------------------------------------------------------------------------
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Basic \
  --admin-enabled true

ACR_LOGIN_SERVER=$(az acr show --name $ACR_NAME --query loginServer --output tsv)
echo "ACR login server: $ACR_LOGIN_SERVER"

# ---------------------------------------------------------------------------
# 4. Storage Account + Blob container (replaces S3)
# ---------------------------------------------------------------------------
az storage account create \
  --name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --sku Standard_LRS \
  --kind StorageV2 \
  --access-tier Hot

STORAGE_CONNECTION_STRING=$(az storage account show-connection-string \
  --name $STORAGE_ACCOUNT --resource-group $RESOURCE_GROUP --output tsv)

az storage container create \
  --name documents \
  --connection-string "$STORAGE_CONNECTION_STRING"

# Cost optimization: lifecycle policy - move blobs to Cool after 30 days,
# Archive after 90 days
cat > /tmp/blob-lifecycle.json << 'EOF'
{
  "rules": [
    {
      "enabled": true,
      "name": "move-to-cool-then-archive",
      "type": "Lifecycle",
      "definition": {
        "actions": {
          "baseBlob": {
            "tierToCool": { "daysAfterModificationGreaterThan": 30 },
            "tierToArchive": { "daysAfterModificationGreaterThan": 90 }
          }
        },
        "filters": {
          "blobTypes": ["blockBlob"],
          "prefixMatch": ["documents/"]
        }
      }
    }
  ]
}
EOF

az storage account management-policy create \
  --account-name $STORAGE_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --policy @/tmp/blob-lifecycle.json

# ---------------------------------------------------------------------------
# 5. Azure Database for PostgreSQL Flexible Server (+ pgvector)
# ---------------------------------------------------------------------------
# Cost optimization: Burstable B1ms tier for dev (~$12-15/month)
az postgres flexible-server create \
  --resource-group $RESOURCE_GROUP \
  --name $PG_SERVER_NAME \
  --location $LOCATION \
  --admin-user $PG_ADMIN_USER \
  --admin-password "$PG_ADMIN_PASSWORD" \
  --sku-name Standard_B1ms \
  --tier Burstable \
  --storage-size 32 \
  --version 15 \
  --public-access 0.0.0.0-255.255.255.255 \
  --yes
# NOTE: public-access wide-open here is for ACI simplicity (ACI has no
# stable outbound IP without a VNet). In the AKS stage (Part 5.3+) we lock
# this down to VNet-only access - a major security improvement.

az postgres flexible-server db create \
  --resource-group $RESOURCE_GROUP \
  --server-name $PG_SERVER_NAME \
  --database-name docdb

# Enable the pgvector extension via server parameter, then CREATE EXTENSION
az postgres flexible-server parameter set \
  --resource-group $RESOURCE_GROUP \
  --server-name $PG_SERVER_NAME \
  --name azure.extensions \
  --value vector

PG_HOST="${PG_SERVER_NAME}.postgres.database.azure.com"

# Connect and enable extension (requires psql client installed locally)
PGPASSWORD="$PG_ADMIN_PASSWORD" psql \
  "host=$PG_HOST port=5432 dbname=docdb user=$PG_ADMIN_USER sslmode=require" \
  -c "CREATE EXTENSION IF NOT EXISTS vector;"

# ---------------------------------------------------------------------------
# 6. Azure OpenAI (AI Layer)
# ---------------------------------------------------------------------------
# NOTE: Azure OpenAI requires approved access on your subscription.
# Apply at https://aka.ms/oai/access if not already enabled.
az cognitiveservices account create \
  --name $OPENAI_RESOURCE_NAME \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --kind OpenAI \
  --sku S0 \
  --yes

az cognitiveservices account deployment create \
  --name $OPENAI_RESOURCE_NAME \
  --resource-group $RESOURCE_GROUP \
  --deployment-name gpt-4o-mini-deployment \
  --model-name gpt-4o-mini \
  --model-version "2024-07-18" \
  --model-format OpenAI \
  --sku-name "Standard" \
  --sku-capacity 10

az cognitiveservices account deployment create \
  --name $OPENAI_RESOURCE_NAME \
  --resource-group $RESOURCE_GROUP \
  --deployment-name text-embedding-3-small-deployment \
  --model-name text-embedding-3-small \
  --model-version "1" \
  --model-format OpenAI \
  --sku-name "Standard" \
  --sku-capacity 10

AZURE_OPENAI_ENDPOINT=$(az cognitiveservices account show \
  --name $OPENAI_RESOURCE_NAME --resource-group $RESOURCE_GROUP \
  --query properties.endpoint --output tsv)

AZURE_OPENAI_KEY=$(az cognitiveservices account keys list \
  --name $OPENAI_RESOURCE_NAME --resource-group $RESOURCE_GROUP \
  --query key1 --output tsv)

# ---------------------------------------------------------------------------
# 7. Azure Document Intelligence (OCR)
# ---------------------------------------------------------------------------
az cognitiveservices account create \
  --name $DOC_INTEL_RESOURCE_NAME \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --kind FormRecognizer \
  --sku S0 \
  --yes

AZURE_DOC_INTEL_ENDPOINT=$(az cognitiveservices account show \
  --name $DOC_INTEL_RESOURCE_NAME --resource-group $RESOURCE_GROUP \
  --query properties.endpoint --output tsv)

AZURE_DOC_INTEL_KEY=$(az cognitiveservices account keys list \
  --name $DOC_INTEL_RESOURCE_NAME --resource-group $RESOURCE_GROUP \
  --query key1 --output tsv)

# ---------------------------------------------------------------------------
# 8. Key Vault (stores all secrets centrally)
# ---------------------------------------------------------------------------
az keyvault create \
  --name $KEYVAULT_NAME \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION

az keyvault secret set --vault-name $KEYVAULT_NAME --name "database-url" \
  --value "postgresql+psycopg2://${PG_ADMIN_USER}:${PG_ADMIN_PASSWORD}@${PG_HOST}:5432/docdb?sslmode=require"
az keyvault secret set --vault-name $KEYVAULT_NAME --name "storage-connection-string" \
  --value "$STORAGE_CONNECTION_STRING"
az keyvault secret set --vault-name $KEYVAULT_NAME --name "azure-openai-endpoint" \
  --value "$AZURE_OPENAI_ENDPOINT"
az keyvault secret set --vault-name $KEYVAULT_NAME --name "azure-openai-key" \
  --value "$AZURE_OPENAI_KEY"
az keyvault secret set --vault-name $KEYVAULT_NAME --name "azure-docintel-endpoint" \
  --value "$AZURE_DOC_INTEL_ENDPOINT"
az keyvault secret set --vault-name $KEYVAULT_NAME --name "azure-docintel-key" \
  --value "$AZURE_DOC_INTEL_KEY"
az keyvault secret set --vault-name $KEYVAULT_NAME --name "app-secret-key" \
  --value "$(openssl rand -hex 32)"

echo "All secrets stored in Key Vault: $KEYVAULT_NAME"

# ---------------------------------------------------------------------------
# 9. Build and push Docker images to ACR
# ---------------------------------------------------------------------------
az acr login --name $ACR_NAME

docker build -t $ACR_LOGIN_SERVER/doc-platform-backend:v1 ./backend
docker push $ACR_LOGIN_SERVER/doc-platform-backend:v1

docker build \
  --build-arg VITE_API_BASE_URL=http://localhost:8001/api/v1 \
  -t $ACR_LOGIN_SERVER/doc-platform-frontend:v1 ./frontend
docker push $ACR_LOGIN_SERVER/doc-platform-frontend:v1

# ---------------------------------------------------------------------------
# 10. Deploy Backend to ACI
# ---------------------------------------------------------------------------
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --query username --output tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query passwords[0].value --output tsv)

az container create \
  --resource-group $RESOURCE_GROUP \
  --name doc-platform-backend \
  --image $ACR_LOGIN_SERVER/doc-platform-backend:v1 \
  --registry-login-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --cpu 1 \
  --memory 1.5 \
  --ports 8000 \
  --ip-address Public \
  --dns-name-label doc-platform-backend-$RANDOM \
  --environment-variables \
    ENV=dev \
    AZURE_STORAGE_USE_MANAGED_IDENTITY=false \
    AZURE_STORAGE_CONTAINER_NAME=documents \
    AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini-deployment \
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small-deployment \
    AZURE_OPENAI_API_VERSION=2024-02-15-preview \
  --secure-environment-variables \
    DATABASE_URL="postgresql+psycopg2://${PG_ADMIN_USER}:${PG_ADMIN_PASSWORD}@${PG_HOST}:5432/docdb?sslmode=require" \
    AZURE_STORAGE_CONNECTION_STRING="$STORAGE_CONNECTION_STRING" \
    AZURE_OPENAI_ENDPOINT="$AZURE_OPENAI_ENDPOINT" \
    AZURE_OPENAI_API_KEY="$AZURE_OPENAI_KEY" \
    AZURE_DOC_INTEL_ENDPOINT="$AZURE_DOC_INTEL_ENDPOINT" \
    AZURE_DOC_INTEL_KEY="$AZURE_DOC_INTEL_KEY" \
    SECRET_KEY="$(openssl rand -hex 32)"

BACKEND_FQDN=$(az container show --resource-group $RESOURCE_GROUP \
  --name doc-platform-backend --query ipAddress.fqdn --output tsv)
echo "Backend running at: http://$BACKEND_FQDN:8000"

# ---------------------------------------------------------------------------
# 11. Deploy Frontend to ACI
# ---------------------------------------------------------------------------
az container create \
  --resource-group $RESOURCE_GROUP \
  --name doc-platform-frontend \
  --image $ACR_LOGIN_SERVER/doc-platform-frontend:v1 \
  --registry-login-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --cpu 0.5 \
  --memory 1 \
  --ports 80 \
  --ip-address Public \
  --dns-name-label doc-platform-frontend-$RANDOM

FRONTEND_FQDN=$(az container show --resource-group $RESOURCE_GROUP \
  --name doc-platform-frontend --query ipAddress.fqdn --output tsv)
echo "Frontend running at: http://$FRONTEND_FQDN"

echo "================================================================"
echo " STAGE 1 (ACI) DEPLOYMENT COMPLETE"
echo " Backend:  http://$BACKEND_FQDN:8000/api/docs"
echo " Frontend: http://$FRONTEND_FQDN"
echo "================================================================"
echo "NOTE: frontend was built with VITE_API_BASE_URL pointing to"
echo "localhost. For a real working frontend->backend connection in ACI,"
echo "rebuild frontend with --build-arg VITE_API_BASE_URL=http://$BACKEND_FQDN:8000/api/v1"
echo "and re-push/re-deploy. This is exactly the kind of friction AKS +"
echo "Ingress solves properly (Part 5.3 onward)."
