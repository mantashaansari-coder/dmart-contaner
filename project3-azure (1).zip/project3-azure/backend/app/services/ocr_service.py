from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from app.core.config import get_settings

settings = get_settings()


class OCRService:
    """
    OCR via Azure Document Intelligence (formerly Form Recognizer).
    Uses the prebuilt-read model which handles printed and handwritten
    text across PDFs and images - covers invoices, contracts, resumes,
    medical reports, and financial statements without needing a custom
    model per document type.
    """

    def __init__(self):
        self.client = DocumentAnalysisClient(
            endpoint=settings.AZURE_DOC_INTEL_ENDPOINT,
            credential=AzureKeyCredential(settings.AZURE_DOC_INTEL_KEY),
        )

    def extract_text(self, file_bytes: bytes) -> str:
        poller = self.client.begin_analyze_document("prebuilt-read", document=file_bytes)
        result = poller.result()

        lines = []
        for page in result.pages:
            for line in page.lines:
                lines.append(line.content)
        return "\n".join(lines)


ocr_service = OCRService()
