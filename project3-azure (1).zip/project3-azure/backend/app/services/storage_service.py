import uuid
from datetime import datetime, timedelta
from azure.storage.blob import (
    BlobServiceClient,
    generate_blob_sas,
    BlobSasPermissions,
)
from azure.identity import DefaultAzureCredential
from app.core.config import get_settings

settings = get_settings()


class StorageService:
    """
    Wraps Azure Blob Storage operations (replaces AWS S3 in the full-Azure
    deployment).

    Two auth modes:
      1. Connection string (simplest, used for ACI / local dev)
      2. Managed Identity / Workload Identity (used in AKS production -
         no secrets stored at all, the AKS pod authenticates directly
         to Azure AD)

    Cost optimization:
      - Container uses Cool access tier by default for documents older
        than 30 days via a Lifecycle Management policy (configured in
        Terraform, not here) - cheaper than Hot tier for infrequently
        accessed documents.
      - We generate SAS URLs for direct client downloads instead of
        proxying file bytes through the API pod, saving compute time
        and egress cost on the API side.
    """

    def __init__(self):
        self.container_name = settings.AZURE_STORAGE_CONTAINER_NAME

        if settings.AZURE_STORAGE_USE_MANAGED_IDENTITY:
            account_url = f"https://{settings.AZURE_STORAGE_ACCOUNT_NAME}.blob.core.windows.net"
            credential = DefaultAzureCredential()
            self.blob_service_client = BlobServiceClient(
                account_url=account_url, credential=credential
            )
        else:
            self.blob_service_client = BlobServiceClient.from_connection_string(
                settings.AZURE_STORAGE_CONNECTION_STRING
            )

        # Ensure container exists (idempotent)
        try:
            self.blob_service_client.create_container(self.container_name)
        except Exception:
            pass  # already exists

    def generate_key(self, owner_id: str, filename: str) -> str:
        unique_id = uuid.uuid4().hex
        return f"documents/{owner_id}/{unique_id}_{filename}"

    def upload_fileobj(self, fileobj, key: str, content_type: str = None):
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=key
        )
        content_settings = None
        if content_type:
            from azure.storage.blob import ContentSettings
            content_settings = ContentSettings(content_type=content_type)

        blob_client.upload_blob(
            fileobj, overwrite=True, content_settings=content_settings
        )

    def get_object_bytes(self, key: str) -> bytes:
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=key
        )
        return blob_client.download_blob().readall()

    def generate_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        """
        Generates a SAS (Shared Access Signature) URL - Azure's equivalent
        of an S3 presigned URL.
        """
        account_name = self.blob_service_client.account_name
        account_key = self._get_account_key()

        sas_token = generate_blob_sas(
            account_name=account_name,
            container_name=self.container_name,
            blob_name=key,
            account_key=account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(seconds=expires_in),
        )
        blob_url = (
            f"https://{account_name}.blob.core.windows.net/"
            f"{self.container_name}/{key}?{sas_token}"
        )
        return blob_url

    def _get_account_key(self) -> str:
        """
        SAS generation requires the account key. When using Managed Identity
        (no key available), use User Delegation SAS instead - this is the
        production-recommended path and avoids ever handling a storage key.
        """
        if settings.AZURE_STORAGE_USE_MANAGED_IDENTITY:
            raise RuntimeError(
                "Account-key SAS not available with Managed Identity. "
                "Use generate_user_delegation_sas() instead (see below)."
            )
        # Extract from connection string
        parts = dict(
            p.split("=", 1)
            for p in settings.AZURE_STORAGE_CONNECTION_STRING.split(";")
            if "=" in p
        )
        return parts.get("AccountKey", "")

    def generate_user_delegation_sas(self, key: str, expires_in: int = 3600) -> str:
        """
        Production path for AKS + Managed Identity: requests a short-lived
        delegation key from Azure AD instead of using a static account key.
        """
        account_name = self.blob_service_client.account_name
        start_time = datetime.utcnow()
        expiry_time = start_time + timedelta(seconds=expires_in)

        delegation_key = self.blob_service_client.get_user_delegation_key(
            key_start_time=start_time, key_expiry_time=expiry_time
        )

        sas_token = generate_blob_sas(
            account_name=account_name,
            container_name=self.container_name,
            blob_name=key,
            user_delegation_key=delegation_key,
            permission=BlobSasPermissions(read=True),
            expiry=expiry_time,
        )
        return (
            f"https://{account_name}.blob.core.windows.net/"
            f"{self.container_name}/{key}?{sas_token}"
        )

    def delete_object(self, key: str):
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, blob=key
        )
        blob_client.delete_blob()


storage_service = StorageService()
