"""
Core configuration module - AZURE-ONLY variant.
All values are loaded from environment variables.
In AKS, these env vars are injected via Kubernetes Secrets synced from
Azure Key Vault (see k8s-azure/base/secret-provider-class.yaml).
"""

from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ---------- App ----------
    APP_NAME: str = "Enterprise AI Document Processing Platform"
    ENV: str = "local"  # local | dev | staging | prod
    API_V1_PREFIX: str = "/api/v1"
    SECRET_KEY: str = "CHANGE_ME_IN_PROD"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # ---------- Database (Azure Database for PostgreSQL Flexible Server) ----------
    DATABASE_URL: str = (
        "postgresql+psycopg2://docuser:docpass@localhost:5432/docdb"
    )

    # ---------- Azure Blob Storage (replaces S3) ----------
    AZURE_STORAGE_CONNECTION_STRING: str | None = None
    AZURE_STORAGE_ACCOUNT_NAME: str | None = None
    AZURE_STORAGE_CONTAINER_NAME: str = "documents"
    # When running in AKS with Workload Identity, prefer this over connection string
    AZURE_STORAGE_USE_MANAGED_IDENTITY: bool = False

    # ---------- Azure OpenAI (AI Layer) ----------
    AZURE_OPENAI_ENDPOINT: str | None = None
    AZURE_OPENAI_API_KEY: str | None = None
    AZURE_OPENAI_DEPLOYMENT: str = "gpt-4o-mini-deployment"
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT: str = "text-embedding-3-small-deployment"
    AZURE_OPENAI_API_VERSION: str = "2024-02-15-preview"

    # ---------- Azure Document Intelligence (OCR) ----------
    AZURE_DOC_INTEL_ENDPOINT: str | None = None
    AZURE_DOC_INTEL_KEY: str | None = None

    # ---------- CORS ----------
    CORS_ORIGINS: str = "*"

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
