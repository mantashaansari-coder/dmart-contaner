variable "project_name" {}
variable "environment" {}
variable "location" {}
variable "resource_group_name" {}

resource "azurerm_container_registry" "main" {
  name                = "${var.project_name}${var.environment}acr"
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = "Standard" # Standard supports geo-replication later if needed; Basic is cheaper if you don't need it
  admin_enabled       = false      # we use AcrPull role assignment instead - more secure

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

# Cost optimization: retention policy to auto-purge untagged manifests after 7 days
resource "azurerm_container_registry_task" "purge_untagged" {
  name                  = "purge-untagged-manifests"
  container_registry_id = azurerm_container_registry.main.id

  platform {
    os = "Linux"
  }

  encoded_step {
    task_content = base64encode(<<-EOF
      version: v1.1.0
      steps:
        - cmd: acr purge --filter '.*:.*' --untagged --ago 7d
          disableWorkingDirectoryOverride: true
          timeout: 3600
    EOF
    )
  }

  trigger {
    schedule_trigger {
      name     = "weekly-purge"
      schedule = "0 0 * * 0" # every Sunday midnight
      enabled  = true
    }
  }

  identity {
    type = "SystemAssigned"
  }
}

resource "azurerm_role_assignment" "purge_task_acrdelete" {
  scope                = azurerm_container_registry.main.id
  role_definition_name = "AcrDelete"
  principal_id          = azurerm_container_registry_task.purge_untagged.identity[0].principal_id
}

output "acr_id" {
  value = azurerm_container_registry.main.id
}

output "acr_login_server" {
  value = azurerm_container_registry.main.login_server
}

output "acr_name" {
  value = azurerm_container_registry.main.name
}
