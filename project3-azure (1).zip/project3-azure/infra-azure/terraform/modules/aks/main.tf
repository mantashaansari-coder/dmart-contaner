variable "project_name" {}
variable "environment" {}
variable "location" {}
variable "resource_group_name" {}
variable "kubernetes_version" {}
variable "aks_subnet_id" {}
variable "node_vm_size" {}
variable "node_count" {}
variable "min_node_count" {}
variable "max_node_count" {}
variable "use_spot_node_pool" {}
variable "acr_id" {}

locals {
  cluster_name = "${var.project_name}-${var.environment}-aks"
}

# ---------------------------------------------------------------------------
# AKS Cluster
# ---------------------------------------------------------------------------
# Key design decisions explained:
#  - System-assigned managed identity: AKS manages its own Azure AD identity,
#    no service principal secrets to rotate (legacy approach, avoided here).
#  - Azure CNI (not kubenet): pods get real VNet IPs, enabling direct
#    integration with private Postgres, Key Vault CSI driver, App Gateway
#    Ingress Controller, and NSG-level traffic control.
#  - Workload Identity (OIDC issuer + workload identity enabled): lets pods
#    authenticate to Azure resources (Key Vault, Blob, OpenAI) using a
#    federated identity - NO secrets stored in the cluster at all. This is
#    the AKS equivalent of AWS IRSA from Part 4.
#  - Separate system pool (control-plane-adjacent workloads) and user pool
#    (our app) - standard production pattern, isolates app scaling/restarts
#    from critical system pods like CoreDNS / metrics-server.
# ---------------------------------------------------------------------------
resource "azurerm_kubernetes_cluster" "main" {
  name                = local.cluster_name
  location            = var.location
  resource_group_name = var.resource_group_name
  dns_prefix          = local.cluster_name
  kubernetes_version  = var.kubernetes_version

  # System node pool - runs CoreDNS, metrics-server, our future
  # ingress-nginx/cert-manager controllers. Kept small and stable.
  default_node_pool {
    name                 = "system"
    vm_size              = "Standard_D2s_v5"
    vnet_subnet_id       = var.aks_subnet_id
    node_count           = 1
    auto_scaling_enabled = true
    min_count            = 1
    max_count            = 2
    os_disk_size_gb      = 30
    os_disk_type         = "Managed"

    only_critical_addons_enabled = true # forces app workloads onto user pool below
  }

  identity {
    type = "SystemAssigned"
  }

  # Workload Identity - the IRSA equivalent for Azure
  oidc_issuer_enabled       = true
  workload_identity_enabled = true

  network_profile {
    network_plugin    = "azure"
    network_policy    = "azure"
    load_balancer_sku = "standard"
    service_cidr      = "10.20.0.0/16"
    dns_service_ip    = "10.20.0.10"
  }

  # Cost optimization: short log retention, Free tier control plane
  # (Standard/Premium tiers add SLA + cost; Free is fine for dev/staging)
  sku_tier = var.environment == "prod" ? "Standard" : "Free"

  azure_policy_enabled = true

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

# ---------------------------------------------------------------------------
# User Node Pool - runs our application workloads (backend, frontend)
# Uses Spot VMs for cost optimization in non-prod environments.
# ---------------------------------------------------------------------------
resource "azurerm_kubernetes_cluster_node_pool" "user" {
  name                  = "userpool"
  kubernetes_cluster_id = azurerm_kubernetes_cluster.main.id
  vm_size               = var.node_vm_size
  vnet_subnet_id        = var.aks_subnet_id

  auto_scaling_enabled = true
  node_count           = var.node_count
  min_count            = var.min_node_count
  max_count            = var.max_node_count

  os_disk_size_gb = 30
  mode            = "User"

  priority        = var.use_spot_node_pool && var.environment != "prod" ? "Spot" : "Regular"
  eviction_policy = var.use_spot_node_pool && var.environment != "prod" ? "Delete" : null
  spot_max_price  = var.use_spot_node_pool && var.environment != "prod" ? -1 : null # -1 = pay up to standard price, never evicted purely on price

  node_labels = var.use_spot_node_pool && var.environment != "prod" ? {
    "workload" = "app"
    "pool-type" = "spot"
  } : { "workload" = "app" }

  node_taints = var.use_spot_node_pool && var.environment != "prod" ? [
    "kubernetes.azure.com/scalesetpriority=spot:NoSchedule"
  ] : []

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

# ---------------------------------------------------------------------------
# Grant AKS pull access to ACR (avoids storing registry credentials)
# ---------------------------------------------------------------------------
resource "azurerm_role_assignment" "aks_acr_pull" {
  scope                            = var.acr_id
  role_definition_name             = "AcrPull"
  principal_id                     = azurerm_kubernetes_cluster.main.kubelet_identity[0].object_id
  skip_service_principal_aad_check = true
}

# ---------------------------------------------------------------------------
# Federated credential for Workload Identity (used by External Secrets /
# CSI driver / app pods to access Key Vault, Blob Storage, Azure OpenAI)
# ---------------------------------------------------------------------------
resource "azuread_application" "workload_identity" {
  display_name = "${local.cluster_name}-workload-identity"
}

resource "azuread_service_principal" "workload_identity" {
  client_id = azuread_application.workload_identity.client_id
}

resource "azurerm_federated_identity_credential" "workload_identity" {
  name                = "${local.cluster_name}-fed-cred"
  resource_group_name = var.resource_group_name
  audience            = ["api://AzureADTokenExchange"]
  issuer              = azurerm_kubernetes_cluster.main.oidc_issuer_url
  parent_id           = azurerm_user_assigned_identity.workload_identity.id
  subject             = "system:serviceaccount:doc-platform:doc-platform-sa"
}

resource "azurerm_user_assigned_identity" "workload_identity" {
  name                = "${local.cluster_name}-app-identity"
  location            = var.location
  resource_group_name = var.resource_group_name
}

output "cluster_name" {
  value = azurerm_kubernetes_cluster.main.name
}

output "host" {
  value     = azurerm_kubernetes_cluster.main.kube_config[0].host
  sensitive = true
}

output "client_certificate" {
  value     = azurerm_kubernetes_cluster.main.kube_config[0].client_certificate
  sensitive = true
}

output "client_key" {
  value     = azurerm_kubernetes_cluster.main.kube_config[0].client_key
  sensitive = true
}

output "cluster_ca_certificate" {
  value     = azurerm_kubernetes_cluster.main.kube_config[0].cluster_ca_certificate
  sensitive = true
}

output "oidc_issuer_url" {
  value = azurerm_kubernetes_cluster.main.oidc_issuer_url
}

output "workload_identity_client_id" {
  value = azurerm_user_assigned_identity.workload_identity.client_id
}

output "workload_identity_principal_id" {
  value = azurerm_user_assigned_identity.workload_identity.principal_id
}

output "node_resource_group" {
  value = azurerm_kubernetes_cluster.main.node_resource_group
}
