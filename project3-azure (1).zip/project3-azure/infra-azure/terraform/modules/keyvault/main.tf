variable "project_name" {}
variable "environment" {}
variable "location" {}
variable "resource_group_name" {}
variable "tenant_id" {}
variable "workload_identity_principal_id" {}

variable "database_url" { sensitive = true }
variable "storage_connection_string" { sensitive = true }
variable "azure_openai_endpoint" {}
variable "azure_openai_key" { sensitive = true }
variable "azure_docintel_endpoint" {}
variable "azure_docintel_key" { sensitive = true }
variable "app_secret_key" { sensitive = true }

resource "random_string" "kv_suffix" {
  length  = 6
  special = false
  upper   = false
}

resource "azurerm_key_vault" "main" {
  name                       = "${var.project_name}-${var.environment}-kv-${random_string.kv_suffix.result}"
  location                   = var.location
  resource_group_name        = var.resource_group_name
  tenant_id                  = var.tenant_id
  sku_name                   = "standard"
  purge_protection_enabled   = false # set true for prod
  soft_delete_retention_days = 7

  rbac_authorization_enabled = true # modern approach over legacy access policies

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

# Grant the AKS Workload Identity permission to READ secrets
resource "azurerm_role_assignment" "workload_identity_kv_reader" {
  scope                = azurerm_key_vault.main.id
  role_definition_name = "Key Vault Secrets User"
  principal_id          = var.workload_identity_principal_id
}

resource "azurerm_key_vault_secret" "database_url" {
  name         = "database-url"
  value        = var.database_url
  key_vault_id = azurerm_key_vault.main.id
}

resource "azurerm_key_vault_secret" "storage_connection_string" {
  name         = "storage-connection-string"
  value        = var.storage_connection_string
  key_vault_id = azurerm_key_vault.main.id
}

resource "azurerm_key_vault_secret" "azure_openai_endpoint" {
  name         = "azure-openai-endpoint"
  value        = var.azure_openai_endpoint
  key_vault_id = azurerm_key_vault.main.id
}

resource "azurerm_key_vault_secret" "azure_openai_key" {
  name         = "azure-openai-key"
  value        = var.azure_openai_key
  key_vault_id = azurerm_key_vault.main.id
}

resource "azurerm_key_vault_secret" "azure_docintel_endpoint" {
  name         = "azure-docintel-endpoint"
  value        = var.azure_docintel_endpoint
  key_vault_id = azurerm_key_vault.main.id
}

resource "azurerm_key_vault_secret" "azure_docintel_key" {
  name         = "azure-docintel-key"
  value        = var.azure_docintel_key
  key_vault_id = azurerm_key_vault.main.id
}

resource "azurerm_key_vault_secret" "app_secret_key" {
  name         = "app-secret-key"
  value        = var.app_secret_key
  key_vault_id = azurerm_key_vault.main.id
}

output "key_vault_name" {
  value = azurerm_key_vault.main.name
}

output "key_vault_uri" {
  value = azurerm_key_vault.main.vault_uri
}
