variable "domain_name" {}
variable "resource_group_name" {}
variable "create_zone" {}

resource "azurerm_dns_zone" "main" {
  count               = var.create_zone ? 1 : 0
  name                = var.domain_name
  resource_group_name = var.resource_group_name
}

data "azurerm_dns_zone" "existing" {
  count               = var.create_zone ? 0 : 1
  name                = var.domain_name
  resource_group_name = var.resource_group_name
}

locals {
  zone_name = var.create_zone ? azurerm_dns_zone.main[0].name : data.azurerm_dns_zone.existing[0].name
}

output "zone_id" {
  value = var.create_zone ? azurerm_dns_zone.main[0].id : data.azurerm_dns_zone.existing[0].id
}

output "name_servers" {
  value = var.create_zone ? azurerm_dns_zone.main[0].name_servers : []
}

output "zone_name" {
  value = local.zone_name
}
