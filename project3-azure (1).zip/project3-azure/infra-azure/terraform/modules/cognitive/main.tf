variable "project_name" {}
variable "environment" {}
variable "location" {}
variable "resource_group_name" {}

# ---------------------------------------------------------------------------
# Azure OpenAI
# ---------------------------------------------------------------------------
# NOTE: Azure OpenAI requires approved access on your subscription
# (apply at https://aka.ms/oai/access). Also only available in certain
# regions - if `var.location` doesn't support it, override openai_location.
resource "azurerm_cognitive_account" "openai" {
  name                = "${var.project_name}-${var.environment}-openai"
  location            = var.location
  resource_group_name = var.resource_group_name
  kind                = "OpenAI"
  sku_name            = "S0"

  custom_subdomain_name = "${var.project_name}-${var.environment}-openai"

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

resource "azurerm_cognitive_deployment" "chat" {
  name                 = "gpt-4o-mini-deployment"
  cognitive_account_id = azurerm_cognitive_account.openai.id

  model {
    format  = "OpenAI"
    name    = "gpt-4o-mini"
    version = "2024-07-18"
  }

  sku {
    name     = "Standard"
    capacity = 10 # cost optimization: low TPM quota for dev, raise for prod load
  }
}

resource "azurerm_cognitive_deployment" "embedding" {
  name                 = "text-embedding-3-small-deployment"
  cognitive_account_id = azurerm_cognitive_account.openai.id

  model {
    format  = "OpenAI"
    name    = "text-embedding-3-small"
    version = "1"
  }

  sku {
    name     = "Standard"
    capacity = 10
  }
}

# ---------------------------------------------------------------------------
# Azure Document Intelligence (OCR)
# ---------------------------------------------------------------------------
resource "azurerm_cognitive_account" "doc_intelligence" {
  name                = "${var.project_name}-${var.environment}-docintel"
  location            = var.location
  resource_group_name = var.resource_group_name
  kind                = "FormRecognizer"
  sku_name            = "S0"

  custom_subdomain_name = "${var.project_name}-${var.environment}-docintel"

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

output "openai_endpoint" {
  value = azurerm_cognitive_account.openai.endpoint
}

output "openai_primary_key" {
  value     = azurerm_cognitive_account.openai.primary_access_key
  sensitive = true
}

output "doc_intelligence_endpoint" {
  value = azurerm_cognitive_account.doc_intelligence.endpoint
}

output "doc_intelligence_primary_key" {
  value     = azurerm_cognitive_account.doc_intelligence.primary_access_key
  sensitive = true
}
