variable "project_name" {}
variable "environment" {}
variable "location" {}
variable "resource_group_name" {}
variable "db_subnet_id" {}
variable "private_dns_zone_id" {}
variable "sku_name" {}
variable "storage_mb" {}
variable "pg_version" {}
variable "admin_username" {}
variable "admin_password" { sensitive = true }
variable "database_name" {}
variable "geo_redundant_backup" {}

resource "azurerm_postgresql_flexible_server" "main" {
  name                = "${var.project_name}-${var.environment}-pg"
  resource_group_name = var.resource_group_name
  location            = var.location

  version    = var.pg_version
  sku_name   = var.sku_name
  storage_mb = var.storage_mb

  administrator_login    = var.admin_username
  administrator_password = var.admin_password

  # Private access only - no public IP exposure (major security upgrade
  # vs the ACI stage, where we had to open Postgres to the internet).
  delegated_subnet_id = var.db_subnet_id
  private_dns_zone_id = var.private_dns_zone_id

  backup_retention_days        = var.environment == "prod" ? 7 : 3
  geo_redundant_backup_enabled = var.geo_redundant_backup

  zone = "1"

  tags = {
    Project     = var.project_name
    Environment = var.environment
  }
}

resource "azurerm_postgresql_flexible_server_database" "main" {
  name      = var.database_name
  server_id = azurerm_postgresql_flexible_server.main.id
  charset   = "UTF8"
  collation = "en_US.utf8"
}

# Enable pgvector extension at the server level
resource "azurerm_postgresql_flexible_server_configuration" "extensions" {
  name      = "azure.extensions"
  server_id = azurerm_postgresql_flexible_server.main.id
  value     = "vector"
}

output "server_fqdn" {
  value = azurerm_postgresql_flexible_server.main.fqdn
}

output "database_name" {
  value = azurerm_postgresql_flexible_server_database.main.name
}
