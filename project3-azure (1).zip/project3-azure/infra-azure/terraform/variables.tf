variable "location" {
  description = "Azure region to deploy into"
  type        = string
  default     = "centralindia"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "project_name" {
  description = "Project name used as prefix for resources"
  type        = string
  default     = "docplatform"
}

# ---------------- Networking ----------------
variable "vnet_address_space" {
  type    = list(string)
  default = ["10.10.0.0/16"]
}

variable "aks_subnet_cidr" {
  type    = string
  default = "10.10.1.0/24"
}

variable "db_subnet_cidr" {
  type    = string
  default = "10.10.2.0/24"
}

variable "appgw_subnet_cidr" {
  type    = string
  default = "10.10.3.0/24"
}

# ---------------- AKS ----------------
variable "kubernetes_version" {
  description = "AKS Kubernetes version"
  type        = string
  default     = "1.29"
}

variable "aks_node_vm_size" {
  description = "VM size for AKS system node pool"
  type        = string
  default     = "Standard_D2s_v5"
}

variable "aks_node_count" {
  type    = number
  default = 2
}

variable "aks_min_node_count" {
  type    = number
  default = 1
}

variable "aks_max_node_count" {
  type    = number
  default = 4
}

variable "use_spot_node_pool" {
  description = "Add a Spot user node pool for app workloads (cost optimization)"
  type        = bool
  default     = true
}

# ---------------- PostgreSQL ----------------
variable "pg_sku_name" {
  description = "Azure DB for PostgreSQL Flexible Server SKU"
  type        = string
  default     = "B_Standard_B1ms" # Burstable - cheapest viable tier for dev
}

variable "pg_storage_mb" {
  type    = number
  default = 32768
}

variable "pg_version" {
  type    = string
  default = "15"
}

variable "pg_admin_username" {
  type    = string
  default = "docadmin"
}

variable "pg_database_name" {
  type    = string
  default = "docdb"
}

variable "pg_geo_redundant_backup" {
  description = "Enable geo-redundant backups (extra cost; set true for prod)"
  type        = bool
  default     = false
}

# ---------------- Storage ----------------
variable "storage_replication_type" {
  description = "LRS is cheapest (single region); use GRS for prod DR"
  type        = string
  default     = "LRS"
}

# ---------------- DNS ----------------
variable "domain_name" {
  description = "Root domain name for the application"
  type        = string
  default     = "yourdomain.com"
}

variable "create_dns_zone" {
  description = "Whether Terraform should create a new DNS zone"
  type        = bool
  default     = false
}

# ---------------- Secrets ----------------
variable "app_secret_key" {
  description = "JWT signing secret"
  type        = string
  sensitive   = true
  default     = ""
}
