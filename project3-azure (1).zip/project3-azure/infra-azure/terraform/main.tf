resource "azurerm_resource_group" "main" {
  name     = "${var.project_name}-${var.environment}-rg"
  location = var.location
}

resource "random_password" "pg_admin_password" {
  length  = 24
  special = false
}

# ---------------- Network ----------------
module "network" {
  source               = "./modules/network"
  project_name         = var.project_name
  environment          = var.environment
  location             = var.location
  resource_group_name  = azurerm_resource_group.main.name
  vnet_address_space   = var.vnet_address_space
  aks_subnet_cidr      = var.aks_subnet_cidr
  db_subnet_cidr       = var.db_subnet_cidr
  appgw_subnet_cidr    = var.appgw_subnet_cidr
}

# ---------------- ACR ----------------
module "acr" {
  source               = "./modules/acr"
  project_name         = var.project_name
  environment          = var.environment
  location             = var.location
  resource_group_name  = azurerm_resource_group.main.name
}

# ---------------- AKS ----------------
module "aks" {
  source               = "./modules/aks"
  project_name         = var.project_name
  environment          = var.environment
  location             = var.location
  resource_group_name  = azurerm_resource_group.main.name
  kubernetes_version   = var.kubernetes_version
  aks_subnet_id        = module.network.aks_subnet_id
  node_vm_size         = var.aks_node_vm_size
  node_count           = var.aks_node_count
  min_node_count       = var.aks_min_node_count
  max_node_count       = var.aks_max_node_count
  use_spot_node_pool   = var.use_spot_node_pool
  acr_id               = module.acr.acr_id
}

# ---------------- PostgreSQL ----------------
module "postgres" {
  source                = "./modules/postgres"
  project_name          = var.project_name
  environment           = var.environment
  location              = var.location
  resource_group_name   = azurerm_resource_group.main.name
  db_subnet_id          = module.network.db_subnet_id
  private_dns_zone_id   = module.network.postgres_private_dns_zone_id
  sku_name              = var.pg_sku_name
  storage_mb            = var.pg_storage_mb
  pg_version            = var.pg_version
  admin_username        = var.pg_admin_username
  admin_password        = random_password.pg_admin_password.result
  database_name         = var.pg_database_name
  geo_redundant_backup  = var.pg_geo_redundant_backup
}

# ---------------- Storage ----------------
module "storage" {
  source               = "./modules/storage"
  project_name         = var.project_name
  environment          = var.environment
  location             = var.location
  resource_group_name  = azurerm_resource_group.main.name
  replication_type     = var.storage_replication_type
}

# ---------------- Cognitive Services (AI Layer) ----------------
module "cognitive" {
  source               = "./modules/cognitive"
  project_name         = var.project_name
  environment          = var.environment
  location             = var.location
  resource_group_name  = azurerm_resource_group.main.name
}

# ---------------- Key Vault ----------------
module "keyvault" {
  source                          = "./modules/keyvault"
  project_name                    = var.project_name
  environment                     = var.environment
  location                        = var.location
  resource_group_name             = azurerm_resource_group.main.name
  tenant_id                       = data.azurerm_client_config.current.tenant_id
  workload_identity_principal_id  = module.aks.workload_identity_principal_id

  database_url               = "postgresql+psycopg2://${var.pg_admin_username}:${random_password.pg_admin_password.result}@${module.postgres.server_fqdn}:5432/${var.pg_database_name}?sslmode=require"
  storage_connection_string  = module.storage.primary_connection_string
  azure_openai_endpoint      = module.cognitive.openai_endpoint
  azure_openai_key           = module.cognitive.openai_primary_key
  azure_docintel_endpoint    = module.cognitive.doc_intelligence_endpoint
  azure_docintel_key         = module.cognitive.doc_intelligence_primary_key
  app_secret_key             = var.app_secret_key
}

# ---------------- DNS ----------------
module "dns" {
  source               = "./modules/dns"
  domain_name          = var.domain_name
  resource_group_name  = azurerm_resource_group.main.name
  create_zone          = var.create_dns_zone
}

# ---------------------------------------------------------------------------
# ingress-nginx - handles HTTP routing inside AKS (simpler and more portable
# than Azure Application Gateway Ingress Controller for this workload;
# exposed via a Kubernetes LoadBalancer Service which provisions an Azure
# Standard Load Balancer automatically)
# ---------------------------------------------------------------------------
resource "helm_release" "ingress_nginx" {
  name             = "ingress-nginx"
  repository       = "https://kubernetes.github.io/ingress-nginx"
  chart            = "ingress-nginx"
  namespace        = "ingress-nginx"
  create_namespace = true
  version          = "4.11.1"

  set {
    name  = "controller.replicaCount"
    value = "2"
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/azure-load-balancer-health-probe-request-path"
    value = "/healthz"
  }
  set {
    name  = "controller.resources.requests.cpu"
    value = "100m"
  }
  set {
    name  = "controller.resources.requests.memory"
    value = "128Mi"
  }

  depends_on = [module.aks]
}

# ---------------------------------------------------------------------------
# cert-manager - automatic TLS certificates from Let's Encrypt
# ---------------------------------------------------------------------------
resource "helm_release" "cert_manager" {
  name             = "cert-manager"
  repository       = "https://charts.jetstack.io"
  chart            = "cert-manager"
  namespace        = "cert-manager"
  create_namespace = true
  version          = "v1.15.1"

  set {
    name  = "installCRDs"
    value = "true"
  }
  set {
    name  = "resources.requests.cpu"
    value = "50m"
  }
  set {
    name  = "resources.requests.memory"
    value = "64Mi"
  }

  depends_on = [module.aks]
}

# ---------------------------------------------------------------------------
# Azure Key Vault Provider for Secrets Store CSI Driver - mounts Key Vault
# secrets directly into pods as files/env vars via Workload Identity, no
# External Secrets Operator needed (this is the native Azure-idiomatic path).
# ---------------------------------------------------------------------------
resource "helm_release" "csi_secrets_store" {
  name             = "csi-secrets-store"
  repository       = "https://raw.githubusercontent.com/Azure/secrets-store-csi-driver-provider-azure/master/charts"
  chart            = "csi-secrets-store-provider-azure"
  namespace        = "kube-system"
  version          = "1.5.3"

  depends_on = [module.aks]
}

output "summary" {
  value = <<-EOT
    ===========================================
    Azure AKS Deployment - Infrastructure Summary
    ===========================================
    Resource Group:    ${azurerm_resource_group.main.name}
    AKS Cluster:       ${module.aks.cluster_name}
    Postgres FQDN:     ${module.postgres.server_fqdn}
    Storage Account:   ${module.storage.storage_account_name}
    ACR:               ${module.acr.acr_login_server}
    Key Vault:         ${module.keyvault.key_vault_name}
    Azure OpenAI:      ${module.cognitive.openai_endpoint}
    Doc Intelligence:  ${module.cognitive.doc_intelligence_endpoint}
    DNS Zone:          ${module.dns.zone_name}
    Workload Identity Client ID: ${module.aks.workload_identity_client_id}
    ===========================================
  EOT
}

output "resource_group_name" {
  value = azurerm_resource_group.main.name
}

output "aks_cluster_name" {
  value = module.aks.cluster_name
}

output "acr_login_server" {
  value = module.acr.acr_login_server
}

output "acr_name" {
  value = module.acr.acr_name
}

output "key_vault_name" {
  value = module.keyvault.key_vault_name
}

output "key_vault_uri" {
  value = module.keyvault.key_vault_uri
}

output "workload_identity_client_id" {
  value = module.aks.workload_identity_client_id
}

output "node_resource_group" {
  value = module.aks.node_resource_group
}

output "dns_name_servers" {
  value = module.dns.name_servers
}

output "postgres_fqdn" {
  value = module.postgres.server_fqdn
}
