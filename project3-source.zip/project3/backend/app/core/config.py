"""
Core configuration module.
All values are loaded from environment variables.
In production (EKS), these env vars are injected via Kubernetes Secrets
which are synced from AWS Secrets Manager (see infra/external-secrets.yaml).
"""

from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ---------- App ----------
    APP_NAME: str = "Enterprise AI Document Processing Platform"
    ENV: str = "local"  # local | dev | staging | prod
    API_V1_PREFIX: str = "/api/v1"
    SECRET_KEY: str = "CHANGE_ME_IN_PROD"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # ---------- Database ----------
    DATABASE_URL: str = (
        "postgresql+psycopg2://docuser:docpass@localhost:5432/docdb"
    )

    # ---------- AWS ----------
    AWS_REGION: str = "ap-south-1"
    S3_BUCKET_NAME: str = "enterprise-doc-platform-bucket"
    AWS_ACCESS_KEY_ID: str | None = None
    AWS_SECRET_ACCESS_KEY: str | None = None

    # ---------- AI Provider ----------
    # "openai" or "azure_openai"
    AI_PROVIDER: str = "openai"

    # OpenAI
    OPENAI_API_KEY: str | None = None
    OPENAI_MODEL: str = "gpt-4o-mini"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-3-small"

    # Azure OpenAI
    AZURE_OPENAI_ENDPOINT: str | None = None
    AZURE_OPENAI_API_KEY: str | None = None
    AZURE_OPENAI_DEPLOYMENT: str | None = None
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT: str | None = None
    AZURE_OPENAI_API_VERSION: str = "2024-02-15-preview"

    # ---------- OCR Provider ----------
    # "textract" or "azure_doc_intelligence"
    OCR_PROVIDER: str = "textract"

    # Azure Document Intelligence
    AZURE_DOC_INTEL_ENDPOINT: str | None = None
    AZURE_DOC_INTEL_KEY: str | None = None

    # ---------- CORS ----------
    CORS_ORIGINS: str = "*"

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
