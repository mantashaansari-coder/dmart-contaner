from pydantic import BaseModel, EmailStr
from typing import Optional, List
from uuid import UUID
from datetime import datetime
from app.models.models import DocumentStatus, DocumentType


# ---------------- Auth ----------------
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None
    organization: Optional[str] = None


class UserOut(BaseModel):
    id: UUID
    email: EmailStr
    full_name: Optional[str]
    organization: Optional[str]

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# ---------------- Documents ----------------
class DocumentOut(BaseModel):
    id: UUID
    filename: str
    doc_type: DocumentType
    status: DocumentStatus
    summary: Optional[str] = None
    ai_analysis: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class DocumentDetailOut(DocumentOut):
    extracted_text: Optional[str] = None


class UploadResponse(BaseModel):
    document_id: UUID
    filename: str
    status: DocumentStatus


# ---------------- Semantic Search ----------------
class SearchRequest(BaseModel):
    query: str
    top_k: int = 5


class SearchResult(BaseModel):
    document_id: UUID
    filename: str
    chunk_content: str
    score: float


class SearchResponse(BaseModel):
    results: List[SearchResult]
