import uuid
import boto3
from botocore.exceptions import ClientError
from app.core.config import get_settings

settings = get_settings()


class StorageService:
    """
    Wraps AWS S3 operations.
    Cost optimization:
      - Use presigned URLs for direct upload/download where possible
        to avoid streaming large files through the API pods.
      - Bucket has lifecycle rules (configured via Terraform) to move
        objects to S3-IA after 30 days and Glacier after 90 days.
    """

    def __init__(self):
        self.client = boto3.client("s3", region_name=settings.AWS_REGION)
        self.bucket = settings.S3_BUCKET_NAME

    def generate_key(self, owner_id: str, filename: str) -> str:
        unique_id = uuid.uuid4().hex
        return f"documents/{owner_id}/{unique_id}_{filename}"

    def upload_fileobj(self, fileobj, key: str, content_type: str = None):
        extra_args = {}
        if content_type:
            extra_args["ContentType"] = content_type
        self.client.upload_fileobj(fileobj, self.bucket, key, ExtraArgs=extra_args)

    def get_object_bytes(self, key: str) -> bytes:
        response = self.client.get_object(Bucket=self.bucket, Key=key)
        return response["Body"].read()

    def generate_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        try:
            url = self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket, "Key": key},
                ExpiresIn=expires_in,
            )
            return url
        except ClientError as e:
            raise RuntimeError(f"Could not generate presigned URL: {e}")

    def delete_object(self, key: str):
        self.client.delete_object(Bucket=self.bucket, Key=key)


storage_service = StorageService()
