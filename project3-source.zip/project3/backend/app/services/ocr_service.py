import boto3
from app.core.config import get_settings

settings = get_settings()


class OCRService:
    """
    Pluggable OCR service.
    OCR_PROVIDER = "textract" (AWS, default for Part 1 single-cloud deployment)
    OCR_PROVIDER = "azure_doc_intelligence" (used in Multi-cloud deployment)
    """

    def __init__(self):
        self.provider = settings.OCR_PROVIDER
        if self.provider == "textract":
            self.textract_client = boto3.client(
                "textract", region_name=settings.AWS_REGION
            )

    def extract_text(self, file_bytes: bytes) -> str:
        if self.provider == "textract":
            return self._extract_with_textract(file_bytes)
        elif self.provider == "azure_doc_intelligence":
            return self._extract_with_azure(file_bytes)
        else:
            raise ValueError(f"Unsupported OCR provider: {self.provider}")

    # -------------------- AWS Textract --------------------
    def _extract_with_textract(self, file_bytes: bytes) -> str:
        """
        Synchronous Textract call - suitable for documents up to ~5MB.
        For larger / multi-page async docs, use start_document_text_detection
        with S3 input + SNS notification (recommended for production scale).
        """
        response = self.textract_client.detect_document_text(
            Document={"Bytes": file_bytes}
        )
        lines = []
        for block in response.get("Blocks", []):
            if block["BlockType"] == "LINE":
                lines.append(block.get("Text", ""))
        return "\n".join(lines)

    # -------------------- Azure Document Intelligence --------------------
    def _extract_with_azure(self, file_bytes: bytes) -> str:
        from azure.ai.formrecognizer import DocumentAnalysisClient
        from azure.core.credentials import AzureKeyCredential

        client = DocumentAnalysisClient(
            endpoint=settings.AZURE_DOC_INTEL_ENDPOINT,
            credential=AzureKeyCredential(settings.AZURE_DOC_INTEL_KEY),
        )
        poller = client.begin_analyze_document(
            "prebuilt-read", document=file_bytes
        )
        result = poller.result()

        lines = []
        for page in result.pages:
            for line in page.lines:
                lines.append(line.content)
        return "\n".join(lines)


ocr_service = OCRService()
