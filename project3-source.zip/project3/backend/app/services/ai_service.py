import json
from openai import OpenAI, AzureOpenAI
from app.core.config import get_settings

settings = get_settings()


class AIService:
    """
    Pluggable AI service.
    AI_PROVIDER = "openai" (default, single-cloud)
    AI_PROVIDER = "azure_openai" (multi-cloud: AWS infra + Azure AI layer)
    """

    def __init__(self):
        self.provider = settings.AI_PROVIDER

        if self.provider == "openai":
            self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
            self.chat_model = settings.OPENAI_MODEL
            self.embedding_model = settings.OPENAI_EMBEDDING_MODEL
        elif self.provider == "azure_openai":
            self.client = AzureOpenAI(
                api_key=settings.AZURE_OPENAI_API_KEY,
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                api_version=settings.AZURE_OPENAI_API_VERSION,
            )
            self.chat_model = settings.AZURE_OPENAI_DEPLOYMENT
            self.embedding_model = settings.AZURE_OPENAI_EMBEDDING_DEPLOYMENT
        else:
            raise ValueError(f"Unsupported AI provider: {self.provider}")

    # -------------------- Summarization --------------------
    def summarize(self, text: str, doc_type: str = "OTHER") -> str:
        """
        Cost optimization: truncate input text to ~6000 chars (~1500 tokens)
        to control token usage on large documents. For very large docs,
        a chunk-then-reduce summarization strategy should be used instead.
        """
        truncated = text[:6000]

        prompt = (
            f"You are an enterprise document analysis assistant. "
            f"The following document is of type '{doc_type}'. "
            f"Provide a concise 4-6 sentence summary highlighting key facts, "
            f"parties involved, dates, amounts, and any action items.\n\n"
            f"DOCUMENT TEXT:\n{truncated}"
        )

        response = self.client.chat.completions.create(
            model=self.chat_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=300,
        )
        return response.choices[0].message.content.strip()

    # -------------------- Structured Analysis --------------------
    def analyze(self, text: str, doc_type: str = "OTHER") -> dict:
        """
        Extract structured fields depending on doc type.
        Returns a dict that gets stored as JSON in ai_analysis column.
        """
        truncated = text[:6000]

        prompt = (
            f"Extract key structured information from this '{doc_type}' document "
            f"as a JSON object. Include fields relevant to the document type "
            f"(e.g., for invoices: vendor, amount, due_date, invoice_number; "
            f"for resumes: candidate_name, skills, years_experience; "
            f"for contracts: parties, effective_date, term, key_obligations; "
            f"for medical reports: patient_name, diagnosis, recommendations; "
            f"for financial statements: company_name, period, revenue, net_income). "
            f"Respond with ONLY valid JSON, no markdown, no explanation.\n\n"
            f"DOCUMENT TEXT:\n{truncated}"
        )

        response = self.client.chat.completions.create(
            model=self.chat_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=400,
        )
        content = response.choices[0].message.content.strip()

        # Strip markdown fences if model adds them
        if content.startswith("```"):
            content = content.strip("`")
            content = content.replace("json\n", "", 1)

        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return {"raw_response": content}

    # -------------------- Embeddings --------------------
    def get_embedding(self, text: str) -> list[float]:
        response = self.client.embeddings.create(
            model=self.embedding_model,
            input=text[:8000],
        )
        return response.data[0].embedding

    # -------------------- RAG Answer --------------------
    def answer_with_context(self, question: str, context_chunks: list[str]) -> str:
        context = "\n\n---\n\n".join(context_chunks)
        prompt = (
            f"Answer the user's question using ONLY the context below. "
            f"If the answer is not in the context, say you don't have enough information.\n\n"
            f"CONTEXT:\n{context}\n\n"
            f"QUESTION: {question}"
        )
        response = self.client.chat.completions.create(
            model=self.chat_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=400,
        )
        return response.choices[0].message.content.strip()


ai_service = AIService()


def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 100) -> list[str]:
    """Simple sliding-window chunking for embeddings/RAG."""
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start = end - overlap
        if start < 0:
            start = 0
        if end >= len(text):
            break
    return [c for c in chunks if c.strip()]
