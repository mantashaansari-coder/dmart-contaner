import json
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, BackgroundTasks
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.models import Document, DocumentChunk, DocumentStatus, DocumentType, User
from app.schemas.schemas import (
    UploadResponse, DocumentOut, DocumentDetailOut, SearchRequest, SearchResponse, SearchResult
)
from app.services.storage_service import storage_service
from app.services.ocr_service import ocr_service
from app.services.ai_service import ai_service, chunk_text

router = APIRouter(prefix="/documents", tags=["Documents"])


# ----------------------------------------------------------------------
# Upload endpoint - stores file in S3 and creates a DB record.
# Heavy processing (OCR + AI) is kicked off as a background task so the
# API responds quickly (important for UX and avoids ALB timeout).
# ----------------------------------------------------------------------
@router.post("/upload", response_model=UploadResponse)
def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    doc_type: DocumentType = Form(DocumentType.OTHER),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    s3_key = storage_service.generate_key(str(current_user.id), file.filename)
    storage_service.upload_fileobj(file.file, s3_key, content_type=file.content_type)

    document = Document(
        owner_id=current_user.id,
        filename=file.filename,
        s3_key=s3_key,
        content_type=file.content_type,
        doc_type=doc_type,
        status=DocumentStatus.UPLOADED,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    background_tasks.add_task(process_document, str(document.id))

    return UploadResponse(
        document_id=document.id, filename=document.filename, status=document.status
    )


# ----------------------------------------------------------------------
# Background processing pipeline: OCR -> Summarize -> Analyze -> Embed
# ----------------------------------------------------------------------
def process_document(document_id: str):
    from app.core.database import SessionLocal

    db = SessionLocal()
    try:
        document = db.query(Document).filter(Document.id == document_id).first()
        if not document:
            return

        document.status = DocumentStatus.PROCESSING
        db.commit()

        # 1. Download file bytes from S3
        file_bytes = storage_service.get_object_bytes(document.s3_key)

        # 2. OCR
        extracted_text = ocr_service.extract_text(file_bytes)
        document.extracted_text = extracted_text
        document.status = DocumentStatus.OCR_DONE
        db.commit()

        # 3. AI Summarization + Structured Analysis
        summary = ai_service.summarize(extracted_text, doc_type=document.doc_type.value)
        analysis = ai_service.analyze(extracted_text, doc_type=document.doc_type.value)

        document.summary = summary
        document.ai_analysis = json.dumps(analysis)
        document.status = DocumentStatus.ANALYZED
        db.commit()

        # 4. Chunk + Embed for semantic search (RAG)
        chunks = chunk_text(extracted_text)
        for idx, chunk in enumerate(chunks):
            embedding = ai_service.get_embedding(chunk)
            doc_chunk = DocumentChunk(
                document_id=document.id,
                chunk_index=idx,
                content=chunk,
                embedding=embedding,
            )
            db.add(doc_chunk)
        db.commit()

    except Exception as e:
        document = db.query(Document).filter(Document.id == document_id).first()
        if document:
            document.status = DocumentStatus.FAILED
            document.ai_analysis = json.dumps({"error": str(e)})
            db.commit()
    finally:
        db.close()


# ----------------------------------------------------------------------
# List documents for current user
# ----------------------------------------------------------------------
@router.get("", response_model=list[DocumentOut])
def list_documents(
    db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    docs = (
        db.query(Document)
        .filter(Document.owner_id == current_user.id)
        .order_by(Document.created_at.desc())
        .all()
    )
    return docs


# ----------------------------------------------------------------------
# Get single document detail (includes extracted text)
# ----------------------------------------------------------------------
@router.get("/{document_id}", response_model=DocumentDetailOut)
def get_document(
    document_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    document = (
        db.query(Document)
        .filter(Document.id == document_id, Document.owner_id == current_user.id)
        .first()
    )
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document


# ----------------------------------------------------------------------
# Get a presigned download URL for the original file
# ----------------------------------------------------------------------
@router.get("/{document_id}/download-url")
def get_download_url(
    document_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    document = (
        db.query(Document)
        .filter(Document.id == document_id, Document.owner_id == current_user.id)
        .first()
    )
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    url = storage_service.generate_presigned_url(document.s3_key)
    return {"url": url}


# ----------------------------------------------------------------------
# Semantic Search (RAG) across all of the user's documents
# ----------------------------------------------------------------------
@router.post("/search", response_model=SearchResponse)
def semantic_search(
    payload: SearchRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query_embedding = ai_service.get_embedding(payload.query)

    # pgvector cosine distance search, scoped to current user's documents
    stmt = (
        select(
            DocumentChunk.document_id,
            DocumentChunk.content,
            Document.filename,
            DocumentChunk.embedding.cosine_distance(query_embedding).label("distance"),
        )
        .join(Document, Document.id == DocumentChunk.document_id)
        .where(Document.owner_id == current_user.id)
        .order_by("distance")
        .limit(payload.top_k)
    )

    rows = db.execute(stmt).all()

    results = [
        SearchResult(
            document_id=row.document_id,
            filename=row.filename,
            chunk_content=row.content,
            score=float(1 - row.distance),  # convert distance to similarity
        )
        for row in rows
    ]
    return SearchResponse(results=results)


# ----------------------------------------------------------------------
# RAG-based Q&A endpoint - answers questions using retrieved chunks
# ----------------------------------------------------------------------
@router.post("/ask")
def ask_question(
    payload: SearchRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query_embedding = ai_service.get_embedding(payload.query)

    stmt = (
        select(DocumentChunk.content)
        .join(Document, Document.id == DocumentChunk.document_id)
        .where(Document.owner_id == current_user.id)
        .order_by(DocumentChunk.embedding.cosine_distance(query_embedding))
        .limit(payload.top_k)
    )
    rows = db.execute(stmt).all()
    context_chunks = [row.content for row in rows]

    if not context_chunks:
        return {"answer": "No documents found to answer this question."}

    answer = ai_service.answer_with_context(payload.query, context_chunks)
    return {"answer": answer, "sources_used": len(context_chunks)}
