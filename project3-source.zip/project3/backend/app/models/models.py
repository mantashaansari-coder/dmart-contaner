import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Enum, Integer
from sqlalchemy.dialects.postgresql import UUID
from pgvector.sqlalchemy import Vector
from app.core.database import Base
import enum


class DocumentStatus(str, enum.Enum):
    UPLOADED = "UPLOADED"
    PROCESSING = "PROCESSING"
    OCR_DONE = "OCR_DONE"
    ANALYZED = "ANALYZED"
    FAILED = "FAILED"


class DocumentType(str, enum.Enum):
    PDF = "PDF"
    INVOICE = "INVOICE"
    CONTRACT = "CONTRACT"
    RESUME = "RESUME"
    MEDICAL_REPORT = "MEDICAL_REPORT"
    FINANCIAL_STATEMENT = "FINANCIAL_STATEMENT"
    OTHER = "OTHER"


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    organization = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Document(Base):
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    filename = Column(String, nullable=False)
    s3_key = Column(String, nullable=False)
    content_type = Column(String, nullable=True)
    doc_type = Column(Enum(DocumentType), default=DocumentType.OTHER)

    status = Column(Enum(DocumentStatus), default=DocumentStatus.UPLOADED)

    extracted_text = Column(Text, nullable=True)
    summary = Column(Text, nullable=True)
    ai_analysis = Column(Text, nullable=True)  # JSON string of structured insights

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class DocumentChunk(Base):
    """
    Stores text chunks + embeddings for RAG / semantic search.
    Uses pgvector extension. Dimension 1536 matches
    OpenAI text-embedding-3-small / Azure equivalent.
    """
    __tablename__ = "document_chunks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(1536), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
