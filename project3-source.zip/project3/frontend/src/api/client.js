import axios from 'axios'

// In production, this is set via build-time env var VITE_API_BASE_URL
// pointing to the ALB / API Gateway domain (e.g. https://api.yourdomain.com/api/v1)
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
})

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default apiClient
