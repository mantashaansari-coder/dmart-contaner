import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import Navbar from '../components/Navbar.jsx'
import apiClient from '../api/client.js'

export default function DocumentDetailPage() {
  const { id } = useParams()
  const [doc, setDoc] = useState(null)
  const [downloadUrl, setDownloadUrl] = useState('')

  async function fetchDoc() {
    const res = await apiClient.get(`/documents/${id}`)
    setDoc(res.data)
  }

  async function fetchDownloadUrl() {
    const res = await apiClient.get(`/documents/${id}/download-url`)
    setDownloadUrl(res.data.url)
  }

  useEffect(() => {
    fetchDoc()
    fetchDownloadUrl()
    const interval = setInterval(fetchDoc, 5000)
    return () => clearInterval(interval)
  }, [id])

  if (!doc) return <div className="p-6">Loading...</div>

  let analysis = {}
  try {
    analysis = doc.ai_analysis ? JSON.parse(doc.ai_analysis) : {}
  } catch {
    analysis = { raw: doc.ai_analysis }
  }

  return (
    <div>
      <Navbar />
      <div className="max-w-3xl mx-auto p-6">
        <Link to="/" className="text-blue-600 text-sm mb-4 inline-block">&larr; Back to Dashboard</Link>
        <h1 className="text-2xl font-bold mb-1">{doc.filename}</h1>
        <p className="text-sm text-gray-500 mb-4">Status: {doc.status} | Type: {doc.doc_type}</p>

        {downloadUrl && (
          <a href={downloadUrl} target="_blank" rel="noreferrer" className="text-blue-600 underline text-sm">
            Download Original File
          </a>
        )}

        <div className="bg-white rounded shadow p-4 mt-4">
          <h2 className="font-semibold mb-2">AI Summary</h2>
          <p className="text-gray-700 whitespace-pre-line">{doc.summary || 'Processing not complete yet...'}</p>
        </div>

        <div className="bg-white rounded shadow p-4 mt-4">
          <h2 className="font-semibold mb-2">Structured AI Analysis</h2>
          <pre className="text-sm bg-gray-50 p-3 rounded overflow-x-auto">{JSON.stringify(analysis, null, 2)}</pre>
        </div>

        <div className="bg-white rounded shadow p-4 mt-4">
          <h2 className="font-semibold mb-2">Extracted Text (OCR)</h2>
          <p className="text-sm text-gray-600 whitespace-pre-line max-h-96 overflow-y-auto">
            {doc.extracted_text || 'Not extracted yet...'}
          </p>
        </div>
      </div>
    </div>
  )
}
