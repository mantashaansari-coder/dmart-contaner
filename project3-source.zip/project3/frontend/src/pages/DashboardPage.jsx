import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Navbar from '../components/Navbar.jsx'
import apiClient from '../api/client.js'

const DOC_TYPES = ['PDF', 'INVOICE', 'CONTRACT', 'RESUME', 'MEDICAL_REPORT', 'FINANCIAL_STATEMENT', 'OTHER']

export default function DashboardPage() {
  const [documents, setDocuments] = useState([])
  const [file, setFile] = useState(null)
  const [docType, setDocType] = useState('OTHER')
  const [uploading, setUploading] = useState(false)
  const [message, setMessage] = useState('')

  async function fetchDocuments() {
    const res = await apiClient.get('/documents')
    setDocuments(res.data)
  }

  useEffect(() => {
    fetchDocuments()
    const interval = setInterval(fetchDocuments, 5000) // poll for status updates
    return () => clearInterval(interval)
  }, [])

  async function handleUpload(e) {
    e.preventDefault()
    if (!file) return
    setUploading(true)
    setMessage('')
    const formData = new FormData()
    formData.append('file', file)
    formData.append('doc_type', docType)
    try {
      await apiClient.post('/documents/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      setMessage('Uploaded successfully. Processing started.')
      setFile(null)
      fetchDocuments()
    } catch (err) {
      setMessage(err.response?.data?.detail || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  function statusBadge(status) {
    const colors = {
      UPLOADED: 'bg-gray-200 text-gray-800',
      PROCESSING: 'bg-yellow-200 text-yellow-800',
      OCR_DONE: 'bg-blue-200 text-blue-800',
      ANALYZED: 'bg-green-200 text-green-800',
      FAILED: 'bg-red-200 text-red-800',
    }
    return <span className={`text-xs px-2 py-1 rounded ${colors[status] || ''}`}>{status}</span>
  }

  return (
    <div>
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4">Upload Document</h1>
        <form onSubmit={handleUpload} className="bg-white p-4 rounded shadow mb-8 flex gap-3 items-center">
          <input type="file" onChange={(e) => setFile(e.target.files[0])} className="flex-1" />
          <select value={docType} onChange={(e) => setDocType(e.target.value)} className="border rounded px-2 py-1">
            {DOC_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <button type="submit" disabled={uploading} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50">
            {uploading ? 'Uploading...' : 'Upload'}
          </button>
        </form>
        {message && <p className="mb-4 text-sm text-gray-700">{message}</p>}

        <h2 className="text-xl font-bold mb-3">Your Documents</h2>
        <div className="bg-white rounded shadow divide-y">
          {documents.length === 0 && <p className="p-4 text-gray-500">No documents uploaded yet.</p>}
          {documents.map((doc) => (
            <Link
              to={`/documents/${doc.id}`}
              key={doc.id}
              className="flex justify-between items-center p-4 hover:bg-gray-50"
            >
              <div>
                <p className="font-medium">{doc.filename}</p>
                <p className="text-sm text-gray-500">{doc.doc_type}</p>
              </div>
              {statusBadge(doc.status)}
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
