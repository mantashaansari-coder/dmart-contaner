import { useState } from 'react'
import Navbar from '../components/Navbar.jsx'
import apiClient from '../api/client.js'

export default function SearchPage() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [answer, setAnswer] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSearch(e) {
    e.preventDefault()
    setLoading(true)
    setAnswer('')
    try {
      const res = await apiClient.post('/documents/search', { query, top_k: 5 })
      setResults(res.data.results)
    } finally {
      setLoading(false)
    }
  }

  async function handleAsk() {
    setLoading(true)
    try {
      const res = await apiClient.post('/documents/ask', { query, top_k: 5 })
      setAnswer(res.data.answer)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <Navbar />
      <div className="max-w-3xl mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4">Semantic Search (RAG)</h1>
        <form onSubmit={handleSearch} className="flex gap-2 mb-6">
          <input
            type="text"
            placeholder="Ask anything about your documents..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 border rounded px-3 py-2"
          />
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Search
          </button>
          <button type="button" onClick={handleAsk} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            Ask AI
          </button>
        </form>

        {loading && <p>Loading...</p>}

        {answer && (
          <div className="bg-green-50 border border-green-200 rounded p-4 mb-6">
            <h2 className="font-semibold mb-2">AI Answer</h2>
            <p className="text-gray-800">{answer}</p>
          </div>
        )}

        <div className="space-y-3">
          {results.map((r, idx) => (
            <div key={idx} className="bg-white rounded shadow p-4">
              <p className="text-sm text-gray-500 mb-1">{r.filename} — score: {r.score.toFixed(3)}</p>
              <p className="text-gray-800">{r.chunk_content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
