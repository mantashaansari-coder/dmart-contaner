variable "domain_name" {}
variable "create_zone" {}
variable "alb_dns_name" {
  default = ""
}
variable "alb_zone_id" {
  default = ""
}

resource "aws_route53_zone" "main" {
  count = var.create_zone ? 1 : 0
  name  = var.domain_name
}

data "aws_route53_zone" "existing" {
  count        = var.create_zone ? 0 : 1
  name         = var.domain_name
  private_zone = false
}

locals {
  zone_id = var.create_zone ? aws_route53_zone.main[0].zone_id : data.aws_route53_zone.existing[0].zone_id
}

# Alias record pointing apex/subdomain to the ALB
# NOTE: alb_dns_name/alb_zone_id are populated AFTER the AWS Load Balancer
# Controller creates the ALB via Ingress (chicken-and-egg). This resource
# is applied in a second terraform apply pass once the Ingress exists
# (see deployment guide Step 9).
resource "aws_route53_record" "app" {
  count   = var.alb_dns_name != "" ? 1 : 0
  zone_id = local.zone_id
  name    = "app.${var.domain_name}"
  type    = "A"

  alias {
    name                   = var.alb_dns_name
    zone_id                = var.alb_zone_id
    evaluate_target_health = true
  }
}

output "zone_id" {
  value = local.zone_id
}

output "name_servers" {
  value = var.create_zone ? aws_route53_zone.main[0].name_servers : []
}
