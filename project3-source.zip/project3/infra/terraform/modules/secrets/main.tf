variable "project_name" {}
variable "environment" {}
variable "db_password" { sensitive = true }
variable "db_endpoint" {}
variable "db_name" {}
variable "db_username" {}
variable "s3_bucket_name" {}
variable "openai_api_key" { sensitive = true }
variable "app_secret_key" { sensitive = true }

resource "aws_secretsmanager_secret" "app_secrets" {
  name                    = "${var.project_name}-${var.environment}-app-secrets"
  recovery_window_in_days = 0 # set to 7-30 in production to allow recovery

  tags = { Name = "${var.project_name}-app-secrets" }
}

resource "aws_secretsmanager_secret_version" "app_secrets" {
  secret_id = aws_secretsmanager_secret.app_secrets.id

  secret_string = jsonencode({
    DATABASE_URL    = "postgresql+psycopg2://${var.db_username}:${var.db_password}@${var.db_endpoint}/${var.db_name}"
    S3_BUCKET_NAME  = var.s3_bucket_name
    OPENAI_API_KEY  = var.openai_api_key
    SECRET_KEY      = var.app_secret_key
  })
}

output "secret_arn" {
  value = aws_secretsmanager_secret.app_secrets.arn
}

output "secret_name" {
  value = aws_secretsmanager_secret.app_secrets.name
}
