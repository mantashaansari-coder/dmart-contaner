variable "project_name" {}
variable "environment" {}
variable "vpc_id" {}
variable "private_subnet_ids" { type = list(string) }
variable "eks_node_security_group_id" {}
variable "db_instance_class" {}
variable "db_allocated_storage" {}
variable "db_name" {}
variable "db_username" {}
variable "db_multi_az" {}
variable "db_password" {
  sensitive = true
}

resource "aws_db_subnet_group" "main" {
  name       = "${var.project_name}-${var.environment}-db-subnet-group"
  subnet_ids = var.private_subnet_ids
  tags       = { Name = "${var.project_name}-db-subnet-group" }
}

resource "aws_security_group" "rds" {
  name        = "${var.project_name}-${var.environment}-rds-sg"
  description = "Allow Postgres traffic from EKS nodes only"
  vpc_id      = var.vpc_id

  ingress {
    description     = "Postgres from EKS nodes"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [var.eks_node_security_group_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.project_name}-rds-sg" }
}

resource "aws_db_instance" "main" {
  identifier     = "${var.project_name}-${var.environment}-pg"
  engine         = "postgres"
  engine_version = "15.7" # supports pgvector via shared_preload_libraries / CREATE EXTENSION

  instance_class        = var.db_instance_class
  allocated_storage     = var.db_allocated_storage
  storage_type           = "gp3" # cheaper + better baseline performance than gp2
  max_allocated_storage  = var.db_allocated_storage * 3 # storage autoscaling cap

  db_name  = var.db_name
  username = var.db_username
  password = var.db_password

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  multi_az = var.db_multi_az

  # Cost optimization: short backup retention for dev, longer for prod
  backup_retention_period = var.environment == "prod" ? 7 : 1
  skip_final_snapshot     = var.environment != "prod"
  deletion_protection     = var.environment == "prod"

  performance_insights_enabled = false # extra cost; enable only if needed

  publicly_accessible = false

  tags = { Name = "${var.project_name}-${var.environment}-postgres" }
}

output "db_endpoint" {
  value = aws_db_instance.main.endpoint
}

output "db_address" {
  value = aws_db_instance.main.address
}

output "db_security_group_id" {
  value = aws_security_group.rds.id
}
