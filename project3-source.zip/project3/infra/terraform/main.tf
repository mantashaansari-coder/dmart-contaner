resource "random_password" "db_password" {
  length  = 24
  special = false # avoid characters that break connection strings
}

# ---------------- VPC ----------------
module "vpc" {
  source              = "./modules/vpc"
  project_name        = var.project_name
  environment         = var.environment
  vpc_cidr            = var.vpc_cidr
  availability_zones  = var.availability_zones
  cluster_name        = "${var.project_name}-${var.environment}-eks"
}

# ---------------- EKS ----------------
module "eks" {
  source               = "./modules/eks"
  project_name         = var.project_name
  environment          = var.environment
  cluster_version      = var.eks_cluster_version
  vpc_id               = module.vpc.vpc_id
  private_subnet_ids   = module.vpc.private_subnet_ids
  public_subnet_ids    = module.vpc.public_subnet_ids
  node_instance_types  = var.node_instance_types
  node_desired_size    = var.node_desired_size
  node_min_size        = var.node_min_size
  node_max_size        = var.node_max_size
  use_spot_instances   = var.use_spot_instances
}

# ---------------- ECR ----------------
module "ecr" {
  source       = "./modules/ecr"
  project_name = var.project_name
  environment  = var.environment
}

# ---------------- S3 ----------------
module "s3" {
  source       = "./modules/s3"
  project_name = var.project_name
  environment  = var.environment
}

# Security group used by EKS nodes (created implicitly by EKS managed node group).
# We fetch it via data source to wire into the RDS security group rule.
data "aws_security_groups" "eks_node_sg" {
  filter {
    name   = "tag:aws:eks:cluster-name"
    values = [module.eks.cluster_name]
  }
  depends_on = [module.eks]
}

# ---------------- RDS ----------------
module "rds" {
  source                      = "./modules/rds"
  project_name                = var.project_name
  environment                 = var.environment
  vpc_id                      = module.vpc.vpc_id
  private_subnet_ids          = module.vpc.private_subnet_ids
  eks_node_security_group_id  = data.aws_security_groups.eks_node_sg.ids[0]
  db_instance_class           = var.db_instance_class
  db_allocated_storage        = var.db_allocated_storage
  db_name                     = var.db_name
  db_username                 = var.db_username
  db_multi_az                 = var.db_multi_az
  db_password                 = random_password.db_password.result
}

# ---------------- Secrets Manager ----------------
module "secrets" {
  source         = "./modules/secrets"
  project_name   = var.project_name
  environment    = var.environment
  db_password    = random_password.db_password.result
  db_endpoint    = module.rds.db_address
  db_name        = var.db_name
  db_username    = var.db_username
  s3_bucket_name = module.s3.bucket_name
  openai_api_key = var.openai_api_key
  app_secret_key = var.app_secret_key
}

# ---------------- Route53 (zone only in first pass) ----------------
module "route53" {
  source      = "./modules/route53"
  domain_name = var.domain_name
  create_zone = var.create_route53_zone
}

# ---------------- AWS Load Balancer Controller (via Helm) ----------------
# This installs the controller that watches Kubernetes Ingress resources
# and provisions an ALB automatically.
resource "aws_iam_policy" "alb_controller" {
  name   = "${var.project_name}-${var.environment}-alb-controller-policy"
  # The policy JSON is downloaded from the official AWS Load Balancer
  # Controller repo BEFORE running terraform apply - see Step 6 of the
  # deployment guide (curl command). This avoids vendoring a huge,
  # version-specific (~500 line) policy file that can drift from upstream.
  policy = file("${path.module}/policies/alb-controller-policy.json")
}

resource "aws_iam_role" "alb_controller" {
  name = "${var.project_name}-${var.environment}-alb-controller-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = module.eks.oidc_provider_arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${module.eks.oidc_provider_url}:sub" = "system:serviceaccount:kube-system:aws-load-balancer-controller"
          "${module.eks.oidc_provider_url}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "alb_controller" {
  role       = aws_iam_role.alb_controller.name
  policy_arn = aws_iam_policy.alb_controller.arn
}

resource "kubernetes_service_account" "alb_controller" {
  metadata {
    name      = "aws-load-balancer-controller"
    namespace = "kube-system"
    annotations = {
      "eks.amazonaws.com/role-arn" = aws_iam_role.alb_controller.arn
    }
  }
  depends_on = [module.eks]
}

resource "helm_release" "alb_controller" {
  name       = "aws-load-balancer-controller"
  repository = "https://aws.github.io/eks-charts"
  chart      = "aws-load-balancer-controller"
  namespace  = "kube-system"
  version    = "1.8.1"

  set {
    name  = "clusterName"
    value = module.eks.cluster_name
  }
  set {
    name  = "serviceAccount.create"
    value = "false"
  }
  set {
    name  = "serviceAccount.name"
    value = kubernetes_service_account.alb_controller.metadata[0].name
  }
  set {
    name  = "region"
    value = var.aws_region
  }
  set {
    name  = "vpcId"
    value = module.vpc.vpc_id
  }

  depends_on = [kubernetes_service_account.alb_controller]
}

# ---------------- Cluster Autoscaler (cost optimization: scale nodes to 0/min when idle) ----------------
resource "aws_iam_role" "cluster_autoscaler" {
  name = "${var.project_name}-${var.environment}-cluster-autoscaler-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = { Federated = module.eks.oidc_provider_arn }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${module.eks.oidc_provider_url}:sub" = "system:serviceaccount:kube-system:cluster-autoscaler"
        }
      }
    }]
  })
}

resource "aws_iam_role_policy" "cluster_autoscaler" {
  name = "${var.project_name}-cluster-autoscaler-policy"
  role = aws_iam_role.cluster_autoscaler.name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "autoscaling:DescribeAutoScalingGroups",
        "autoscaling:DescribeAutoScalingInstances",
        "autoscaling:DescribeLaunchConfigurations",
        "autoscaling:DescribeTags",
        "autoscaling:SetDesiredCapacity",
        "autoscaling:TerminateInstanceInAutoScalingGroup",
        "ec2:DescribeLaunchTemplateVersions"
      ]
      Resource = "*"
    }]
  })
}

resource "kubernetes_service_account" "cluster_autoscaler" {
  metadata {
    name      = "cluster-autoscaler"
    namespace = "kube-system"
    annotations = {
      "eks.amazonaws.com/role-arn" = aws_iam_role.cluster_autoscaler.arn
    }
    labels = {
      "k8s-addon" = "cluster-autoscaler.addons.k8s.io"
    }
  }
  depends_on = [module.eks]
}

output "summary" {
  value = <<-EOT
    ===========================================
    AWS EKS Deployment - Infrastructure Summary
    ===========================================
    EKS Cluster:      ${module.eks.cluster_name}
    RDS Endpoint:     ${module.rds.db_endpoint}
    S3 Bucket:        ${module.s3.bucket_name}
    ECR Backend:      ${module.ecr.backend_repo_url}
    ECR Frontend:     ${module.ecr.frontend_repo_url}
    Secrets Name:     ${module.secrets.secret_name}
    Route53 Zone ID:  ${module.route53.zone_id}
    ===========================================
  EOT
}

output "cluster_name" {
  value = module.eks.cluster_name
}

output "ecr_backend_url" {
  value = module.ecr.backend_repo_url
}

output "ecr_frontend_url" {
  value = module.ecr.frontend_repo_url
}

output "s3_bucket_name" {
  value = module.s3.bucket_name
}

output "secrets_manager_name" {
  value = module.secrets.secret_name
}

output "route53_name_servers" {
  value = module.route53.name_servers
}
