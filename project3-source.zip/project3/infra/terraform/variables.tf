variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "ap-south-1"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "project_name" {
  description = "Project name used as prefix for resources"
  type        = string
  default     = "doc-platform"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  description = "List of AZs to use"
  type        = list(string)
  default     = ["ap-south-1a", "ap-south-1b"]
}

variable "eks_cluster_version" {
  description = "Kubernetes version for EKS"
  type        = string
  default     = "1.29"
}

variable "node_instance_types" {
  description = "EC2 instance types for EKS worker nodes"
  type        = list(string)
  default     = ["t3.medium"]
}

variable "node_desired_size" {
  description = "Desired number of worker nodes"
  type        = number
  default     = 2
}

variable "node_min_size" {
  description = "Minimum number of worker nodes"
  type        = number
  default     = 1
}

variable "node_max_size" {
  description = "Maximum number of worker nodes"
  type        = number
  default     = 4
}

variable "use_spot_instances" {
  description = "Use EC2 Spot instances for cost optimization (non-prod)"
  type        = bool
  default     = true
}

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "db_allocated_storage" {
  description = "RDS allocated storage in GB"
  type        = number
  default     = 20
}

variable "db_name" {
  description = "PostgreSQL database name"
  type        = string
  default     = "docdb"
}

variable "db_username" {
  description = "PostgreSQL master username"
  type        = string
  default     = "docuser"
}

variable "db_multi_az" {
  description = "Enable RDS Multi-AZ (set true for prod, false saves cost in dev)"
  type        = bool
  default     = false
}

variable "domain_name" {
  description = "Root domain name registered in Route53 (e.g. example.com)"
  type        = string
  default     = "yourdomain.com"
}

variable "create_route53_zone" {
  description = "Whether Terraform should create a new hosted zone (false if it already exists)"
  type        = bool
  default     = false
}

variable "openai_api_key" {
  description = "OpenAI API key (stored in Secrets Manager, never in state-visible outputs)"
  type        = string
  sensitive   = true
  default     = ""
}

variable "app_secret_key" {
  description = "JWT signing secret for the application"
  type        = string
  sensitive   = true
  default     = ""
}
