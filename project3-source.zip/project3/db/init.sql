-- Run this once on the database before starting the app
-- (the app also creates tables automatically via SQLAlchemy on startup,
--  but the pgvector extension must exist first)

CREATE EXTENSION IF NOT EXISTS vector;
